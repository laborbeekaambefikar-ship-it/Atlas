// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from atlas_interfaces:msg/ShelfTag.idl
// generated code does not contain a copyright notice

#ifndef ATLAS_INTERFACES__MSG__DETAIL__SHELF_TAG__STRUCT_H_
#define ATLAS_INTERFACES__MSG__DETAIL__SHELF_TAG__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'tag_id'
// Member 'shelf_id'
#include "rosidl_runtime_c/string.h"
// Member 'stamp'
#include "builtin_interfaces/msg/detail/time__struct.h"

/// Struct defined in msg/ShelfTag in the package atlas_interfaces.
typedef struct atlas_interfaces__msg__ShelfTag
{
  rosidl_runtime_c__String tag_id;
  rosidl_runtime_c__String shelf_id;
  float distance;
  bool is_home;
  builtin_interfaces__msg__Time stamp;
} atlas_interfaces__msg__ShelfTag;

// Struct for a sequence of atlas_interfaces__msg__ShelfTag.
typedef struct atlas_interfaces__msg__ShelfTag__Sequence
{
  atlas_interfaces__msg__ShelfTag * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} atlas_interfaces__msg__ShelfTag__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // ATLAS_INTERFACES__MSG__DETAIL__SHELF_TAG__STRUCT_H_
