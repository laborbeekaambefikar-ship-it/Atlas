// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from atlas_interfaces:msg/FleetMission.idl
// generated code does not contain a copyright notice

#ifndef ATLAS_INTERFACES__MSG__DETAIL__FLEET_MISSION__STRUCT_HPP_
#define ATLAS_INTERFACES__MSG__DETAIL__FLEET_MISSION__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__atlas_interfaces__msg__FleetMission __attribute__((deprecated))
#else
# define DEPRECATED__atlas_interfaces__msg__FleetMission __declspec(deprecated)
#endif

namespace atlas_interfaces
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct FleetMission_
{
  using Type = FleetMission_<ContainerAllocator>;

  explicit FleetMission_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->mission_id = "";
      this->target_shelf = "";
      this->sku = "";
      this->priority = 0;
      this->status = 0;
    }
  }

  explicit FleetMission_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : mission_id(_alloc),
    target_shelf(_alloc),
    sku(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->mission_id = "";
      this->target_shelf = "";
      this->sku = "";
      this->priority = 0;
      this->status = 0;
    }
  }

  // field types and members
  using _mission_id_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _mission_id_type mission_id;
  using _target_shelf_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _target_shelf_type target_shelf;
  using _sku_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _sku_type sku;
  using _priority_type =
    uint8_t;
  _priority_type priority;
  using _status_type =
    uint8_t;
  _status_type status;

  // setters for named parameter idiom
  Type & set__mission_id(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->mission_id = _arg;
    return *this;
  }
  Type & set__target_shelf(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->target_shelf = _arg;
    return *this;
  }
  Type & set__sku(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->sku = _arg;
    return *this;
  }
  Type & set__priority(
    const uint8_t & _arg)
  {
    this->priority = _arg;
    return *this;
  }
  Type & set__status(
    const uint8_t & _arg)
  {
    this->status = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    atlas_interfaces::msg::FleetMission_<ContainerAllocator> *;
  using ConstRawPtr =
    const atlas_interfaces::msg::FleetMission_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<atlas_interfaces::msg::FleetMission_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<atlas_interfaces::msg::FleetMission_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      atlas_interfaces::msg::FleetMission_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<atlas_interfaces::msg::FleetMission_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      atlas_interfaces::msg::FleetMission_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<atlas_interfaces::msg::FleetMission_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<atlas_interfaces::msg::FleetMission_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<atlas_interfaces::msg::FleetMission_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__atlas_interfaces__msg__FleetMission
    std::shared_ptr<atlas_interfaces::msg::FleetMission_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__atlas_interfaces__msg__FleetMission
    std::shared_ptr<atlas_interfaces::msg::FleetMission_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const FleetMission_ & other) const
  {
    if (this->mission_id != other.mission_id) {
      return false;
    }
    if (this->target_shelf != other.target_shelf) {
      return false;
    }
    if (this->sku != other.sku) {
      return false;
    }
    if (this->priority != other.priority) {
      return false;
    }
    if (this->status != other.status) {
      return false;
    }
    return true;
  }
  bool operator!=(const FleetMission_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct FleetMission_

// alias to use template instance with default allocator
using FleetMission =
  atlas_interfaces::msg::FleetMission_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace atlas_interfaces

#endif  // ATLAS_INTERFACES__MSG__DETAIL__FLEET_MISSION__STRUCT_HPP_
