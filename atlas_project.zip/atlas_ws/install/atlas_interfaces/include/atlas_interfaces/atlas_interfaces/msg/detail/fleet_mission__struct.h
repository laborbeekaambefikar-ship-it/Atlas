// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from atlas_interfaces:msg/FleetMission.idl
// generated code does not contain a copyright notice

#ifndef ATLAS_INTERFACES__MSG__DETAIL__FLEET_MISSION__STRUCT_H_
#define ATLAS_INTERFACES__MSG__DETAIL__FLEET_MISSION__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'mission_id'
// Member 'target_shelf'
// Member 'sku'
#include "rosidl_runtime_c/string.h"

/// Struct defined in msg/FleetMission in the package atlas_interfaces.
typedef struct atlas_interfaces__msg__FleetMission
{
  rosidl_runtime_c__String mission_id;
  rosidl_runtime_c__String target_shelf;
  rosidl_runtime_c__String sku;
  uint8_t priority;
  uint8_t status;
} atlas_interfaces__msg__FleetMission;

// Struct for a sequence of atlas_interfaces__msg__FleetMission.
typedef struct atlas_interfaces__msg__FleetMission__Sequence
{
  atlas_interfaces__msg__FleetMission * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} atlas_interfaces__msg__FleetMission__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // ATLAS_INTERFACES__MSG__DETAIL__FLEET_MISSION__STRUCT_H_
