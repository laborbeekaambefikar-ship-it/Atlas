// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from atlas_interfaces:msg/ShelfTag.idl
// generated code does not contain a copyright notice

#ifndef ATLAS_INTERFACES__MSG__DETAIL__SHELF_TAG__STRUCT_HPP_
#define ATLAS_INTERFACES__MSG__DETAIL__SHELF_TAG__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'stamp'
#include "builtin_interfaces/msg/detail/time__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__atlas_interfaces__msg__ShelfTag __attribute__((deprecated))
#else
# define DEPRECATED__atlas_interfaces__msg__ShelfTag __declspec(deprecated)
#endif

namespace atlas_interfaces
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct ShelfTag_
{
  using Type = ShelfTag_<ContainerAllocator>;

  explicit ShelfTag_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : stamp(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->tag_id = "";
      this->shelf_id = "";
      this->distance = 0.0f;
      this->is_home = false;
    }
  }

  explicit ShelfTag_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : tag_id(_alloc),
    shelf_id(_alloc),
    stamp(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->tag_id = "";
      this->shelf_id = "";
      this->distance = 0.0f;
      this->is_home = false;
    }
  }

  // field types and members
  using _tag_id_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _tag_id_type tag_id;
  using _shelf_id_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _shelf_id_type shelf_id;
  using _distance_type =
    float;
  _distance_type distance;
  using _is_home_type =
    bool;
  _is_home_type is_home;
  using _stamp_type =
    builtin_interfaces::msg::Time_<ContainerAllocator>;
  _stamp_type stamp;

  // setters for named parameter idiom
  Type & set__tag_id(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->tag_id = _arg;
    return *this;
  }
  Type & set__shelf_id(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->shelf_id = _arg;
    return *this;
  }
  Type & set__distance(
    const float & _arg)
  {
    this->distance = _arg;
    return *this;
  }
  Type & set__is_home(
    const bool & _arg)
  {
    this->is_home = _arg;
    return *this;
  }
  Type & set__stamp(
    const builtin_interfaces::msg::Time_<ContainerAllocator> & _arg)
  {
    this->stamp = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    atlas_interfaces::msg::ShelfTag_<ContainerAllocator> *;
  using ConstRawPtr =
    const atlas_interfaces::msg::ShelfTag_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<atlas_interfaces::msg::ShelfTag_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<atlas_interfaces::msg::ShelfTag_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      atlas_interfaces::msg::ShelfTag_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<atlas_interfaces::msg::ShelfTag_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      atlas_interfaces::msg::ShelfTag_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<atlas_interfaces::msg::ShelfTag_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<atlas_interfaces::msg::ShelfTag_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<atlas_interfaces::msg::ShelfTag_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__atlas_interfaces__msg__ShelfTag
    std::shared_ptr<atlas_interfaces::msg::ShelfTag_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__atlas_interfaces__msg__ShelfTag
    std::shared_ptr<atlas_interfaces::msg::ShelfTag_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ShelfTag_ & other) const
  {
    if (this->tag_id != other.tag_id) {
      return false;
    }
    if (this->shelf_id != other.shelf_id) {
      return false;
    }
    if (this->distance != other.distance) {
      return false;
    }
    if (this->is_home != other.is_home) {
      return false;
    }
    if (this->stamp != other.stamp) {
      return false;
    }
    return true;
  }
  bool operator!=(const ShelfTag_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ShelfTag_

// alias to use template instance with default allocator
using ShelfTag =
  atlas_interfaces::msg::ShelfTag_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace atlas_interfaces

#endif  // ATLAS_INTERFACES__MSG__DETAIL__SHELF_TAG__STRUCT_HPP_
