// generated from rosidl_generator_c/resource/idl.h.em
// with input from atlas_interfaces:msg/FleetMission.idl
// generated code does not contain a copyright notice

#ifndef ATLAS_INTERFACES__MSG__FLEET_MISSION_H_
#define ATLAS_INTERFACES__MSG__FLEET_MISSION_H_

#include "atlas_interfaces/msg/detail/fleet_mission__struct.h"
#include "atlas_interfaces/msg/detail/fleet_mission__functions.h"
#include "atlas_interfaces/msg/detail/fleet_mission__type_support.h"

#endif  // ATLAS_INTERFACES__MSG__FLEET_MISSION_H_
