// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from atlas_interfaces:msg/RobotState.idl
// generated code does not contain a copyright notice

#ifndef ATLAS_INTERFACES__MSG__DETAIL__ROBOT_STATE__TRAITS_HPP_
#define ATLAS_INTERFACES__MSG__DETAIL__ROBOT_STATE__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "atlas_interfaces/msg/detail/robot_state__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'pose'
#include "geometry_msgs/msg/detail/pose2_d__traits.hpp"

namespace atlas_interfaces
{

namespace msg
{

inline void to_flow_style_yaml(
  const RobotState & msg,
  std::ostream & out)
{
  out << "{";
  // member: state
  {
    out << "state: ";
    rosidl_generator_traits::value_to_yaml(msg.state, out);
    out << ", ";
  }

  // member: mission_id
  {
    out << "mission_id: ";
    rosidl_generator_traits::value_to_yaml(msg.mission_id, out);
    out << ", ";
  }

  // member: target_shelf
  {
    out << "target_shelf: ";
    rosidl_generator_traits::value_to_yaml(msg.target_shelf, out);
    out << ", ";
  }

  // member: current_sku
  {
    out << "current_sku: ";
    rosidl_generator_traits::value_to_yaml(msg.current_sku, out);
    out << ", ";
  }

  // member: last_tag
  {
    out << "last_tag: ";
    rosidl_generator_traits::value_to_yaml(msg.last_tag, out);
    out << ", ";
  }

  // member: carrying_load
  {
    out << "carrying_load: ";
    rosidl_generator_traits::value_to_yaml(msg.carrying_load, out);
    out << ", ";
  }

  // member: battery_percent
  {
    out << "battery_percent: ";
    rosidl_generator_traits::value_to_yaml(msg.battery_percent, out);
    out << ", ";
  }

  // member: pose
  {
    out << "pose: ";
    to_flow_style_yaml(msg.pose, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const RobotState & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: state
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "state: ";
    rosidl_generator_traits::value_to_yaml(msg.state, out);
    out << "\n";
  }

  // member: mission_id
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "mission_id: ";
    rosidl_generator_traits::value_to_yaml(msg.mission_id, out);
    out << "\n";
  }

  // member: target_shelf
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "target_shelf: ";
    rosidl_generator_traits::value_to_yaml(msg.target_shelf, out);
    out << "\n";
  }

  // member: current_sku
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "current_sku: ";
    rosidl_generator_traits::value_to_yaml(msg.current_sku, out);
    out << "\n";
  }

  // member: last_tag
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "last_tag: ";
    rosidl_generator_traits::value_to_yaml(msg.last_tag, out);
    out << "\n";
  }

  // member: carrying_load
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "carrying_load: ";
    rosidl_generator_traits::value_to_yaml(msg.carrying_load, out);
    out << "\n";
  }

  // member: battery_percent
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "battery_percent: ";
    rosidl_generator_traits::value_to_yaml(msg.battery_percent, out);
    out << "\n";
  }

  // member: pose
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "pose:\n";
    to_block_style_yaml(msg.pose, out, indentation + 2);
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const RobotState & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace atlas_interfaces

namespace rosidl_generator_traits
{

[[deprecated("use atlas_interfaces::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const atlas_interfaces::msg::RobotState & msg,
  std::ostream & out, size_t indentation = 0)
{
  atlas_interfaces::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use atlas_interfaces::msg::to_yaml() instead")]]
inline std::string to_yaml(const atlas_interfaces::msg::RobotState & msg)
{
  return atlas_interfaces::msg::to_yaml(msg);
}

template<>
inline const char * data_type<atlas_interfaces::msg::RobotState>()
{
  return "atlas_interfaces::msg::RobotState";
}

template<>
inline const char * name<atlas_interfaces::msg::RobotState>()
{
  return "atlas_interfaces/msg/RobotState";
}

template<>
struct has_fixed_size<atlas_interfaces::msg::RobotState>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<atlas_interfaces::msg::RobotState>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<atlas_interfaces::msg::RobotState>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // ATLAS_INTERFACES__MSG__DETAIL__ROBOT_STATE__TRAITS_HPP_
