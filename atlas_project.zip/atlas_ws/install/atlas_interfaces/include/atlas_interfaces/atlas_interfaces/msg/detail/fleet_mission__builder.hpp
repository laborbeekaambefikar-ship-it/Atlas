// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from atlas_interfaces:msg/FleetMission.idl
// generated code does not contain a copyright notice

#ifndef ATLAS_INTERFACES__MSG__DETAIL__FLEET_MISSION__BUILDER_HPP_
#define ATLAS_INTERFACES__MSG__DETAIL__FLEET_MISSION__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "atlas_interfaces/msg/detail/fleet_mission__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace atlas_interfaces
{

namespace msg
{

namespace builder
{

class Init_FleetMission_status
{
public:
  explicit Init_FleetMission_status(::atlas_interfaces::msg::FleetMission & msg)
  : msg_(msg)
  {}
  ::atlas_interfaces::msg::FleetMission status(::atlas_interfaces::msg::FleetMission::_status_type arg)
  {
    msg_.status = std::move(arg);
    return std::move(msg_);
  }

private:
  ::atlas_interfaces::msg::FleetMission msg_;
};

class Init_FleetMission_priority
{
public:
  explicit Init_FleetMission_priority(::atlas_interfaces::msg::FleetMission & msg)
  : msg_(msg)
  {}
  Init_FleetMission_status priority(::atlas_interfaces::msg::FleetMission::_priority_type arg)
  {
    msg_.priority = std::move(arg);
    return Init_FleetMission_status(msg_);
  }

private:
  ::atlas_interfaces::msg::FleetMission msg_;
};

class Init_FleetMission_sku
{
public:
  explicit Init_FleetMission_sku(::atlas_interfaces::msg::FleetMission & msg)
  : msg_(msg)
  {}
  Init_FleetMission_priority sku(::atlas_interfaces::msg::FleetMission::_sku_type arg)
  {
    msg_.sku = std::move(arg);
    return Init_FleetMission_priority(msg_);
  }

private:
  ::atlas_interfaces::msg::FleetMission msg_;
};

class Init_FleetMission_target_shelf
{
public:
  explicit Init_FleetMission_target_shelf(::atlas_interfaces::msg::FleetMission & msg)
  : msg_(msg)
  {}
  Init_FleetMission_sku target_shelf(::atlas_interfaces::msg::FleetMission::_target_shelf_type arg)
  {
    msg_.target_shelf = std::move(arg);
    return Init_FleetMission_sku(msg_);
  }

private:
  ::atlas_interfaces::msg::FleetMission msg_;
};

class Init_FleetMission_mission_id
{
public:
  Init_FleetMission_mission_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_FleetMission_target_shelf mission_id(::atlas_interfaces::msg::FleetMission::_mission_id_type arg)
  {
    msg_.mission_id = std::move(arg);
    return Init_FleetMission_target_shelf(msg_);
  }

private:
  ::atlas_interfaces::msg::FleetMission msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::atlas_interfaces::msg::FleetMission>()
{
  return atlas_interfaces::msg::builder::Init_FleetMission_mission_id();
}

}  // namespace atlas_interfaces

#endif  // ATLAS_INTERFACES__MSG__DETAIL__FLEET_MISSION__BUILDER_HPP_
