// generated from rosidl_generator_c/resource/idl.h.em
// with input from atlas_interfaces:msg/ShelfTag.idl
// generated code does not contain a copyright notice

#ifndef ATLAS_INTERFACES__MSG__SHELF_TAG_H_
#define ATLAS_INTERFACES__MSG__SHELF_TAG_H_

#include "atlas_interfaces/msg/detail/shelf_tag__struct.h"
#include "atlas_interfaces/msg/detail/shelf_tag__functions.h"
#include "atlas_interfaces/msg/detail/shelf_tag__type_support.h"

#endif  // ATLAS_INTERFACES__MSG__SHELF_TAG_H_
