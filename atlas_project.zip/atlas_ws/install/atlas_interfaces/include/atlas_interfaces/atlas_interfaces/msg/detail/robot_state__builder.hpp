// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from atlas_interfaces:msg/RobotState.idl
// generated code does not contain a copyright notice

#ifndef ATLAS_INTERFACES__MSG__DETAIL__ROBOT_STATE__BUILDER_HPP_
#define ATLAS_INTERFACES__MSG__DETAIL__ROBOT_STATE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "atlas_interfaces/msg/detail/robot_state__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace atlas_interfaces
{

namespace msg
{

namespace builder
{

class Init_RobotState_pose
{
public:
  explicit Init_RobotState_pose(::atlas_interfaces::msg::RobotState & msg)
  : msg_(msg)
  {}
  ::atlas_interfaces::msg::RobotState pose(::atlas_interfaces::msg::RobotState::_pose_type arg)
  {
    msg_.pose = std::move(arg);
    return std::move(msg_);
  }

private:
  ::atlas_interfaces::msg::RobotState msg_;
};

class Init_RobotState_battery_percent
{
public:
  explicit Init_RobotState_battery_percent(::atlas_interfaces::msg::RobotState & msg)
  : msg_(msg)
  {}
  Init_RobotState_pose battery_percent(::atlas_interfaces::msg::RobotState::_battery_percent_type arg)
  {
    msg_.battery_percent = std::move(arg);
    return Init_RobotState_pose(msg_);
  }

private:
  ::atlas_interfaces::msg::RobotState msg_;
};

class Init_RobotState_carrying_load
{
public:
  explicit Init_RobotState_carrying_load(::atlas_interfaces::msg::RobotState & msg)
  : msg_(msg)
  {}
  Init_RobotState_battery_percent carrying_load(::atlas_interfaces::msg::RobotState::_carrying_load_type arg)
  {
    msg_.carrying_load = std::move(arg);
    return Init_RobotState_battery_percent(msg_);
  }

private:
  ::atlas_interfaces::msg::RobotState msg_;
};

class Init_RobotState_last_tag
{
public:
  explicit Init_RobotState_last_tag(::atlas_interfaces::msg::RobotState & msg)
  : msg_(msg)
  {}
  Init_RobotState_carrying_load last_tag(::atlas_interfaces::msg::RobotState::_last_tag_type arg)
  {
    msg_.last_tag = std::move(arg);
    return Init_RobotState_carrying_load(msg_);
  }

private:
  ::atlas_interfaces::msg::RobotState msg_;
};

class Init_RobotState_current_sku
{
public:
  explicit Init_RobotState_current_sku(::atlas_interfaces::msg::RobotState & msg)
  : msg_(msg)
  {}
  Init_RobotState_last_tag current_sku(::atlas_interfaces::msg::RobotState::_current_sku_type arg)
  {
    msg_.current_sku = std::move(arg);
    return Init_RobotState_last_tag(msg_);
  }

private:
  ::atlas_interfaces::msg::RobotState msg_;
};

class Init_RobotState_target_shelf
{
public:
  explicit Init_RobotState_target_shelf(::atlas_interfaces::msg::RobotState & msg)
  : msg_(msg)
  {}
  Init_RobotState_current_sku target_shelf(::atlas_interfaces::msg::RobotState::_target_shelf_type arg)
  {
    msg_.target_shelf = std::move(arg);
    return Init_RobotState_current_sku(msg_);
  }

private:
  ::atlas_interfaces::msg::RobotState msg_;
};

class Init_RobotState_mission_id
{
public:
  explicit Init_RobotState_mission_id(::atlas_interfaces::msg::RobotState & msg)
  : msg_(msg)
  {}
  Init_RobotState_target_shelf mission_id(::atlas_interfaces::msg::RobotState::_mission_id_type arg)
  {
    msg_.mission_id = std::move(arg);
    return Init_RobotState_target_shelf(msg_);
  }

private:
  ::atlas_interfaces::msg::RobotState msg_;
};

class Init_RobotState_state
{
public:
  Init_RobotState_state()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_RobotState_mission_id state(::atlas_interfaces::msg::RobotState::_state_type arg)
  {
    msg_.state = std::move(arg);
    return Init_RobotState_mission_id(msg_);
  }

private:
  ::atlas_interfaces::msg::RobotState msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::atlas_interfaces::msg::RobotState>()
{
  return atlas_interfaces::msg::builder::Init_RobotState_state();
}

}  // namespace atlas_interfaces

#endif  // ATLAS_INTERFACES__MSG__DETAIL__ROBOT_STATE__BUILDER_HPP_
