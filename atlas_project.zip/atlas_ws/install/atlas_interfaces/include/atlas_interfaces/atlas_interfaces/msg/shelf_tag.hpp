// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ATLAS_INTERFACES__MSG__SHELF_TAG_HPP_
#define ATLAS_INTERFACES__MSG__SHELF_TAG_HPP_

#include "atlas_interfaces/msg/detail/shelf_tag__struct.hpp"
#include "atlas_interfaces/msg/detail/shelf_tag__builder.hpp"
#include "atlas_interfaces/msg/detail/shelf_tag__traits.hpp"
#include "atlas_interfaces/msg/detail/shelf_tag__type_support.hpp"

#endif  // ATLAS_INTERFACES__MSG__SHELF_TAG_HPP_
