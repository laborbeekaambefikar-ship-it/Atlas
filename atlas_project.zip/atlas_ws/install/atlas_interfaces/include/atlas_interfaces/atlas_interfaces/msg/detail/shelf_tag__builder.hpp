// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from atlas_interfaces:msg/ShelfTag.idl
// generated code does not contain a copyright notice

#ifndef ATLAS_INTERFACES__MSG__DETAIL__SHELF_TAG__BUILDER_HPP_
#define ATLAS_INTERFACES__MSG__DETAIL__SHELF_TAG__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "atlas_interfaces/msg/detail/shelf_tag__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace atlas_interfaces
{

namespace msg
{

namespace builder
{

class Init_ShelfTag_stamp
{
public:
  explicit Init_ShelfTag_stamp(::atlas_interfaces::msg::ShelfTag & msg)
  : msg_(msg)
  {}
  ::atlas_interfaces::msg::ShelfTag stamp(::atlas_interfaces::msg::ShelfTag::_stamp_type arg)
  {
    msg_.stamp = std::move(arg);
    return std::move(msg_);
  }

private:
  ::atlas_interfaces::msg::ShelfTag msg_;
};

class Init_ShelfTag_is_home
{
public:
  explicit Init_ShelfTag_is_home(::atlas_interfaces::msg::ShelfTag & msg)
  : msg_(msg)
  {}
  Init_ShelfTag_stamp is_home(::atlas_interfaces::msg::ShelfTag::_is_home_type arg)
  {
    msg_.is_home = std::move(arg);
    return Init_ShelfTag_stamp(msg_);
  }

private:
  ::atlas_interfaces::msg::ShelfTag msg_;
};

class Init_ShelfTag_distance
{
public:
  explicit Init_ShelfTag_distance(::atlas_interfaces::msg::ShelfTag & msg)
  : msg_(msg)
  {}
  Init_ShelfTag_is_home distance(::atlas_interfaces::msg::ShelfTag::_distance_type arg)
  {
    msg_.distance = std::move(arg);
    return Init_ShelfTag_is_home(msg_);
  }

private:
  ::atlas_interfaces::msg::ShelfTag msg_;
};

class Init_ShelfTag_shelf_id
{
public:
  explicit Init_ShelfTag_shelf_id(::atlas_interfaces::msg::ShelfTag & msg)
  : msg_(msg)
  {}
  Init_ShelfTag_distance shelf_id(::atlas_interfaces::msg::ShelfTag::_shelf_id_type arg)
  {
    msg_.shelf_id = std::move(arg);
    return Init_ShelfTag_distance(msg_);
  }

private:
  ::atlas_interfaces::msg::ShelfTag msg_;
};

class Init_ShelfTag_tag_id
{
public:
  Init_ShelfTag_tag_id()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ShelfTag_shelf_id tag_id(::atlas_interfaces::msg::ShelfTag::_tag_id_type arg)
  {
    msg_.tag_id = std::move(arg);
    return Init_ShelfTag_shelf_id(msg_);
  }

private:
  ::atlas_interfaces::msg::ShelfTag msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::atlas_interfaces::msg::ShelfTag>()
{
  return atlas_interfaces::msg::builder::Init_ShelfTag_tag_id();
}

}  // namespace atlas_interfaces

#endif  // ATLAS_INTERFACES__MSG__DETAIL__SHELF_TAG__BUILDER_HPP_
