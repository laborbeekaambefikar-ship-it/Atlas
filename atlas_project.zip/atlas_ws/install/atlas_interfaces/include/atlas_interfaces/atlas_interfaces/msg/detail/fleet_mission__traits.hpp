// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from atlas_interfaces:msg/FleetMission.idl
// generated code does not contain a copyright notice

#ifndef ATLAS_INTERFACES__MSG__DETAIL__FLEET_MISSION__TRAITS_HPP_
#define ATLAS_INTERFACES__MSG__DETAIL__FLEET_MISSION__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "atlas_interfaces/msg/detail/fleet_mission__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace atlas_interfaces
{

namespace msg
{

inline void to_flow_style_yaml(
  const FleetMission & msg,
  std::ostream & out)
{
  out << "{";
  // member: mission_id
  {
    out << "mission_id: ";
    rosidl_generator_traits::value_to_yaml(msg.mission_id, out);
    out << ", ";
  }

  // member: target_shelf
  {
    out << "target_shelf: ";
    rosidl_generator_traits::value_to_yaml(msg.target_shelf, out);
    out << ", ";
  }

  // member: sku
  {
    out << "sku: ";
    rosidl_generator_traits::value_to_yaml(msg.sku, out);
    out << ", ";
  }

  // member: priority
  {
    out << "priority: ";
    rosidl_generator_traits::value_to_yaml(msg.priority, out);
    out << ", ";
  }

  // member: status
  {
    out << "status: ";
    rosidl_generator_traits::value_to_yaml(msg.status, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const FleetMission & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: mission_id
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "mission_id: ";
    rosidl_generator_traits::value_to_yaml(msg.mission_id, out);
    out << "\n";
  }

  // member: target_shelf
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "target_shelf: ";
    rosidl_generator_traits::value_to_yaml(msg.target_shelf, out);
    out << "\n";
  }

  // member: sku
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "sku: ";
    rosidl_generator_traits::value_to_yaml(msg.sku, out);
    out << "\n";
  }

  // member: priority
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "priority: ";
    rosidl_generator_traits::value_to_yaml(msg.priority, out);
    out << "\n";
  }

  // member: status
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "status: ";
    rosidl_generator_traits::value_to_yaml(msg.status, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const FleetMission & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace atlas_interfaces

namespace rosidl_generator_traits
{

[[deprecated("use atlas_interfaces::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const atlas_interfaces::msg::FleetMission & msg,
  std::ostream & out, size_t indentation = 0)
{
  atlas_interfaces::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use atlas_interfaces::msg::to_yaml() instead")]]
inline std::string to_yaml(const atlas_interfaces::msg::FleetMission & msg)
{
  return atlas_interfaces::msg::to_yaml(msg);
}

template<>
inline const char * data_type<atlas_interfaces::msg::FleetMission>()
{
  return "atlas_interfaces::msg::FleetMission";
}

template<>
inline const char * name<atlas_interfaces::msg::FleetMission>()
{
  return "atlas_interfaces/msg/FleetMission";
}

template<>
struct has_fixed_size<atlas_interfaces::msg::FleetMission>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<atlas_interfaces::msg::FleetMission>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<atlas_interfaces::msg::FleetMission>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // ATLAS_INTERFACES__MSG__DETAIL__FLEET_MISSION__TRAITS_HPP_
