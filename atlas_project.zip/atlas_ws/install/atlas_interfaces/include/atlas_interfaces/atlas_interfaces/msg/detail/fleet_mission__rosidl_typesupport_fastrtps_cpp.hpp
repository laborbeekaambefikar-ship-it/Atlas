// generated from rosidl_typesupport_fastrtps_cpp/resource/idl__rosidl_typesupport_fastrtps_cpp.hpp.em
// with input from atlas_interfaces:msg/FleetMission.idl
// generated code does not contain a copyright notice

#ifndef ATLAS_INTERFACES__MSG__DETAIL__FLEET_MISSION__ROSIDL_TYPESUPPORT_FASTRTPS_CPP_HPP_
#define ATLAS_INTERFACES__MSG__DETAIL__FLEET_MISSION__ROSIDL_TYPESUPPORT_FASTRTPS_CPP_HPP_

#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "atlas_interfaces/msg/rosidl_typesupport_fastrtps_cpp__visibility_control.h"
#include "atlas_interfaces/msg/detail/fleet_mission__struct.hpp"

#ifndef _WIN32
# pragma GCC diagnostic push
# pragma GCC diagnostic ignored "-Wunused-parameter"
# ifdef __clang__
#  pragma clang diagnostic ignored "-Wdeprecated-register"
#  pragma clang diagnostic ignored "-Wreturn-type-c-linkage"
# endif
#endif
#ifndef _WIN32
# pragma GCC diagnostic pop
#endif

#include "fastcdr/Cdr.h"

namespace atlas_interfaces
{

namespace msg
{

namespace typesupport_fastrtps_cpp
{

bool
ROSIDL_TYPESUPPORT_FASTRTPS_CPP_PUBLIC_atlas_interfaces
cdr_serialize(
  const atlas_interfaces::msg::FleetMission & ros_message,
  eprosima::fastcdr::Cdr & cdr);

bool
ROSIDL_TYPESUPPORT_FASTRTPS_CPP_PUBLIC_atlas_interfaces
cdr_deserialize(
  eprosima::fastcdr::Cdr & cdr,
  atlas_interfaces::msg::FleetMission & ros_message);

size_t
ROSIDL_TYPESUPPORT_FASTRTPS_CPP_PUBLIC_atlas_interfaces
get_serialized_size(
  const atlas_interfaces::msg::FleetMission & ros_message,
  size_t current_alignment);

size_t
ROSIDL_TYPESUPPORT_FASTRTPS_CPP_PUBLIC_atlas_interfaces
max_serialized_size_FleetMission(
  bool & full_bounded,
  bool & is_plain,
  size_t current_alignment);

}  // namespace typesupport_fastrtps_cpp

}  // namespace msg

}  // namespace atlas_interfaces

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_FASTRTPS_CPP_PUBLIC_atlas_interfaces
const rosidl_message_type_support_t *
  ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_fastrtps_cpp, atlas_interfaces, msg, FleetMission)();

#ifdef __cplusplus
}
#endif

#endif  // ATLAS_INTERFACES__MSG__DETAIL__FLEET_MISSION__ROSIDL_TYPESUPPORT_FASTRTPS_CPP_HPP_
