// generated from rosidl_generator_c/resource/idl.h.em
// with input from atlas_interfaces:msg/RobotState.idl
// generated code does not contain a copyright notice

#ifndef ATLAS_INTERFACES__MSG__ROBOT_STATE_H_
#define ATLAS_INTERFACES__MSG__ROBOT_STATE_H_

#include "atlas_interfaces/msg/detail/robot_state__struct.h"
#include "atlas_interfaces/msg/detail/robot_state__functions.h"
#include "atlas_interfaces/msg/detail/robot_state__type_support.h"

#endif  // ATLAS_INTERFACES__MSG__ROBOT_STATE_H_
