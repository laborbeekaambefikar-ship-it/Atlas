// generated from rosidl_generator_c/resource/idl__functions.h.em
// with input from atlas_interfaces:msg/FleetMission.idl
// generated code does not contain a copyright notice

#ifndef ATLAS_INTERFACES__MSG__DETAIL__FLEET_MISSION__FUNCTIONS_H_
#define ATLAS_INTERFACES__MSG__DETAIL__FLEET_MISSION__FUNCTIONS_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stdlib.h>

#include "rosidl_runtime_c/visibility_control.h"
#include "atlas_interfaces/msg/rosidl_generator_c__visibility_control.h"

#include "atlas_interfaces/msg/detail/fleet_mission__struct.h"

/// Initialize msg/FleetMission message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * atlas_interfaces__msg__FleetMission
 * )) before or use
 * atlas_interfaces__msg__FleetMission__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_atlas_interfaces
bool
atlas_interfaces__msg__FleetMission__init(atlas_interfaces__msg__FleetMission * msg);

/// Finalize msg/FleetMission message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_atlas_interfaces
void
atlas_interfaces__msg__FleetMission__fini(atlas_interfaces__msg__FleetMission * msg);

/// Create msg/FleetMission message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * atlas_interfaces__msg__FleetMission__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_atlas_interfaces
atlas_interfaces__msg__FleetMission *
atlas_interfaces__msg__FleetMission__create();

/// Destroy msg/FleetMission message.
/**
 * It calls
 * atlas_interfaces__msg__FleetMission__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_atlas_interfaces
void
atlas_interfaces__msg__FleetMission__destroy(atlas_interfaces__msg__FleetMission * msg);

/// Check for msg/FleetMission message equality.
/**
 * \param[in] lhs The message on the left hand size of the equality operator.
 * \param[in] rhs The message on the right hand size of the equality operator.
 * \return true if messages are equal, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_atlas_interfaces
bool
atlas_interfaces__msg__FleetMission__are_equal(const atlas_interfaces__msg__FleetMission * lhs, const atlas_interfaces__msg__FleetMission * rhs);

/// Copy a msg/FleetMission message.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source message pointer.
 * \param[out] output The target message pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer is null
 *   or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_atlas_interfaces
bool
atlas_interfaces__msg__FleetMission__copy(
  const atlas_interfaces__msg__FleetMission * input,
  atlas_interfaces__msg__FleetMission * output);

/// Initialize array of msg/FleetMission messages.
/**
 * It allocates the memory for the number of elements and calls
 * atlas_interfaces__msg__FleetMission__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_atlas_interfaces
bool
atlas_interfaces__msg__FleetMission__Sequence__init(atlas_interfaces__msg__FleetMission__Sequence * array, size_t size);

/// Finalize array of msg/FleetMission messages.
/**
 * It calls
 * atlas_interfaces__msg__FleetMission__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_atlas_interfaces
void
atlas_interfaces__msg__FleetMission__Sequence__fini(atlas_interfaces__msg__FleetMission__Sequence * array);

/// Create array of msg/FleetMission messages.
/**
 * It allocates the memory for the array and calls
 * atlas_interfaces__msg__FleetMission__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_atlas_interfaces
atlas_interfaces__msg__FleetMission__Sequence *
atlas_interfaces__msg__FleetMission__Sequence__create(size_t size);

/// Destroy array of msg/FleetMission messages.
/**
 * It calls
 * atlas_interfaces__msg__FleetMission__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_atlas_interfaces
void
atlas_interfaces__msg__FleetMission__Sequence__destroy(atlas_interfaces__msg__FleetMission__Sequence * array);

/// Check for msg/FleetMission message array equality.
/**
 * \param[in] lhs The message array on the left hand size of the equality operator.
 * \param[in] rhs The message array on the right hand size of the equality operator.
 * \return true if message arrays are equal in size and content, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_atlas_interfaces
bool
atlas_interfaces__msg__FleetMission__Sequence__are_equal(const atlas_interfaces__msg__FleetMission__Sequence * lhs, const atlas_interfaces__msg__FleetMission__Sequence * rhs);

/// Copy an array of msg/FleetMission messages.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source array pointer.
 * \param[out] output The target array pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer
 *   is null or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_atlas_interfaces
bool
atlas_interfaces__msg__FleetMission__Sequence__copy(
  const atlas_interfaces__msg__FleetMission__Sequence * input,
  atlas_interfaces__msg__FleetMission__Sequence * output);

#ifdef __cplusplus
}
#endif

#endif  // ATLAS_INTERFACES__MSG__DETAIL__FLEET_MISSION__FUNCTIONS_H_
