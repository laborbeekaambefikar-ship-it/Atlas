// generated from rosidl_generator_c/resource/idl__functions.h.em
// with input from atlas_interfaces:msg/ShelfTag.idl
// generated code does not contain a copyright notice

#ifndef ATLAS_INTERFACES__MSG__DETAIL__SHELF_TAG__FUNCTIONS_H_
#define ATLAS_INTERFACES__MSG__DETAIL__SHELF_TAG__FUNCTIONS_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stdlib.h>

#include "rosidl_runtime_c/visibility_control.h"
#include "atlas_interfaces/msg/rosidl_generator_c__visibility_control.h"

#include "atlas_interfaces/msg/detail/shelf_tag__struct.h"

/// Initialize msg/ShelfTag message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * atlas_interfaces__msg__ShelfTag
 * )) before or use
 * atlas_interfaces__msg__ShelfTag__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_atlas_interfaces
bool
atlas_interfaces__msg__ShelfTag__init(atlas_interfaces__msg__ShelfTag * msg);

/// Finalize msg/ShelfTag message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_atlas_interfaces
void
atlas_interfaces__msg__ShelfTag__fini(atlas_interfaces__msg__ShelfTag * msg);

/// Create msg/ShelfTag message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * atlas_interfaces__msg__ShelfTag__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_atlas_interfaces
atlas_interfaces__msg__ShelfTag *
atlas_interfaces__msg__ShelfTag__create();

/// Destroy msg/ShelfTag message.
/**
 * It calls
 * atlas_interfaces__msg__ShelfTag__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_atlas_interfaces
void
atlas_interfaces__msg__ShelfTag__destroy(atlas_interfaces__msg__ShelfTag * msg);

/// Check for msg/ShelfTag message equality.
/**
 * \param[in] lhs The message on the left hand size of the equality operator.
 * \param[in] rhs The message on the right hand size of the equality operator.
 * \return true if messages are equal, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_atlas_interfaces
bool
atlas_interfaces__msg__ShelfTag__are_equal(const atlas_interfaces__msg__ShelfTag * lhs, const atlas_interfaces__msg__ShelfTag * rhs);

/// Copy a msg/ShelfTag message.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source message pointer.
 * \param[out] output The target message pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer is null
 *   or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_atlas_interfaces
bool
atlas_interfaces__msg__ShelfTag__copy(
  const atlas_interfaces__msg__ShelfTag * input,
  atlas_interfaces__msg__ShelfTag * output);

/// Initialize array of msg/ShelfTag messages.
/**
 * It allocates the memory for the number of elements and calls
 * atlas_interfaces__msg__ShelfTag__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_atlas_interfaces
bool
atlas_interfaces__msg__ShelfTag__Sequence__init(atlas_interfaces__msg__ShelfTag__Sequence * array, size_t size);

/// Finalize array of msg/ShelfTag messages.
/**
 * It calls
 * atlas_interfaces__msg__ShelfTag__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_atlas_interfaces
void
atlas_interfaces__msg__ShelfTag__Sequence__fini(atlas_interfaces__msg__ShelfTag__Sequence * array);

/// Create array of msg/ShelfTag messages.
/**
 * It allocates the memory for the array and calls
 * atlas_interfaces__msg__ShelfTag__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_atlas_interfaces
atlas_interfaces__msg__ShelfTag__Sequence *
atlas_interfaces__msg__ShelfTag__Sequence__create(size_t size);

/// Destroy array of msg/ShelfTag messages.
/**
 * It calls
 * atlas_interfaces__msg__ShelfTag__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_atlas_interfaces
void
atlas_interfaces__msg__ShelfTag__Sequence__destroy(atlas_interfaces__msg__ShelfTag__Sequence * array);

/// Check for msg/ShelfTag message array equality.
/**
 * \param[in] lhs The message array on the left hand size of the equality operator.
 * \param[in] rhs The message array on the right hand size of the equality operator.
 * \return true if message arrays are equal in size and content, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_atlas_interfaces
bool
atlas_interfaces__msg__ShelfTag__Sequence__are_equal(const atlas_interfaces__msg__ShelfTag__Sequence * lhs, const atlas_interfaces__msg__ShelfTag__Sequence * rhs);

/// Copy an array of msg/ShelfTag messages.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source array pointer.
 * \param[out] output The target array pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer
 *   is null or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_atlas_interfaces
bool
atlas_interfaces__msg__ShelfTag__Sequence__copy(
  const atlas_interfaces__msg__ShelfTag__Sequence * input,
  atlas_interfaces__msg__ShelfTag__Sequence * output);

#ifdef __cplusplus
}
#endif

#endif  // ATLAS_INTERFACES__MSG__DETAIL__SHELF_TAG__FUNCTIONS_H_
