// generated from rosidl_generator_cpp/resource/idl.hpp.em
// generated code does not contain a copyright notice

#ifndef ATLAS_INTERFACES__MSG__ROBOT_STATE_HPP_
#define ATLAS_INTERFACES__MSG__ROBOT_STATE_HPP_

#include "atlas_interfaces/msg/detail/robot_state__struct.hpp"
#include "atlas_interfaces/msg/detail/robot_state__builder.hpp"
#include "atlas_interfaces/msg/detail/robot_state__traits.hpp"
#include "atlas_interfaces/msg/detail/robot_state__type_support.hpp"

#endif  // ATLAS_INTERFACES__MSG__ROBOT_STATE_HPP_
