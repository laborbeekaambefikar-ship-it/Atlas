// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from atlas_interfaces:msg/ShelfTag.idl
// generated code does not contain a copyright notice

#ifndef ATLAS_INTERFACES__MSG__DETAIL__SHELF_TAG__TRAITS_HPP_
#define ATLAS_INTERFACES__MSG__DETAIL__SHELF_TAG__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "atlas_interfaces/msg/detail/shelf_tag__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'stamp'
#include "builtin_interfaces/msg/detail/time__traits.hpp"

namespace atlas_interfaces
{

namespace msg
{

inline void to_flow_style_yaml(
  const ShelfTag & msg,
  std::ostream & out)
{
  out << "{";
  // member: tag_id
  {
    out << "tag_id: ";
    rosidl_generator_traits::value_to_yaml(msg.tag_id, out);
    out << ", ";
  }

  // member: shelf_id
  {
    out << "shelf_id: ";
    rosidl_generator_traits::value_to_yaml(msg.shelf_id, out);
    out << ", ";
  }

  // member: distance
  {
    out << "distance: ";
    rosidl_generator_traits::value_to_yaml(msg.distance, out);
    out << ", ";
  }

  // member: is_home
  {
    out << "is_home: ";
    rosidl_generator_traits::value_to_yaml(msg.is_home, out);
    out << ", ";
  }

  // member: stamp
  {
    out << "stamp: ";
    to_flow_style_yaml(msg.stamp, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const ShelfTag & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: tag_id
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "tag_id: ";
    rosidl_generator_traits::value_to_yaml(msg.tag_id, out);
    out << "\n";
  }

  // member: shelf_id
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "shelf_id: ";
    rosidl_generator_traits::value_to_yaml(msg.shelf_id, out);
    out << "\n";
  }

  // member: distance
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "distance: ";
    rosidl_generator_traits::value_to_yaml(msg.distance, out);
    out << "\n";
  }

  // member: is_home
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "is_home: ";
    rosidl_generator_traits::value_to_yaml(msg.is_home, out);
    out << "\n";
  }

  // member: stamp
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "stamp:\n";
    to_block_style_yaml(msg.stamp, out, indentation + 2);
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const ShelfTag & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace atlas_interfaces

namespace rosidl_generator_traits
{

[[deprecated("use atlas_interfaces::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const atlas_interfaces::msg::ShelfTag & msg,
  std::ostream & out, size_t indentation = 0)
{
  atlas_interfaces::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use atlas_interfaces::msg::to_yaml() instead")]]
inline std::string to_yaml(const atlas_interfaces::msg::ShelfTag & msg)
{
  return atlas_interfaces::msg::to_yaml(msg);
}

template<>
inline const char * data_type<atlas_interfaces::msg::ShelfTag>()
{
  return "atlas_interfaces::msg::ShelfTag";
}

template<>
inline const char * name<atlas_interfaces::msg::ShelfTag>()
{
  return "atlas_interfaces/msg/ShelfTag";
}

template<>
struct has_fixed_size<atlas_interfaces::msg::ShelfTag>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<atlas_interfaces::msg::ShelfTag>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<atlas_interfaces::msg::ShelfTag>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // ATLAS_INTERFACES__MSG__DETAIL__SHELF_TAG__TRAITS_HPP_
