// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from atlas_interfaces:msg/RobotState.idl
// generated code does not contain a copyright notice

#ifndef ATLAS_INTERFACES__MSG__DETAIL__ROBOT_STATE__STRUCT_H_
#define ATLAS_INTERFACES__MSG__DETAIL__ROBOT_STATE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'state'
// Member 'mission_id'
// Member 'target_shelf'
// Member 'current_sku'
// Member 'last_tag'
#include "rosidl_runtime_c/string.h"
// Member 'pose'
#include "geometry_msgs/msg/detail/pose2_d__struct.h"

/// Struct defined in msg/RobotState in the package atlas_interfaces.
typedef struct atlas_interfaces__msg__RobotState
{
  rosidl_runtime_c__String state;
  rosidl_runtime_c__String mission_id;
  rosidl_runtime_c__String target_shelf;
  rosidl_runtime_c__String current_sku;
  rosidl_runtime_c__String last_tag;
  bool carrying_load;
  float battery_percent;
  geometry_msgs__msg__Pose2D pose;
} atlas_interfaces__msg__RobotState;

// Struct for a sequence of atlas_interfaces__msg__RobotState.
typedef struct atlas_interfaces__msg__RobotState__Sequence
{
  atlas_interfaces__msg__RobotState * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} atlas_interfaces__msg__RobotState__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // ATLAS_INTERFACES__MSG__DETAIL__ROBOT_STATE__STRUCT_H_
