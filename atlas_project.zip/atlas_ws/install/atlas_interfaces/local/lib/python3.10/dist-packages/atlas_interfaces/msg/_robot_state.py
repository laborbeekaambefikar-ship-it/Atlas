# generated from rosidl_generator_py/resource/_idl.py.em
# with input from atlas_interfaces:msg/RobotState.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import math  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_RobotState(type):
    """Metaclass of message 'RobotState'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('atlas_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'atlas_interfaces.msg.RobotState')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__msg__robot_state
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__msg__robot_state
            cls._CONVERT_TO_PY = module.convert_to_py_msg__msg__robot_state
            cls._TYPE_SUPPORT = module.type_support_msg__msg__robot_state
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__msg__robot_state

            from geometry_msgs.msg import Pose2D
            if Pose2D.__class__._TYPE_SUPPORT is None:
                Pose2D.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class RobotState(metaclass=Metaclass_RobotState):
    """Message class 'RobotState'."""

    __slots__ = [
        '_state',
        '_mission_id',
        '_target_shelf',
        '_current_sku',
        '_last_tag',
        '_carrying_load',
        '_battery_percent',
        '_pose',
    ]

    _fields_and_field_types = {
        'state': 'string',
        'mission_id': 'string',
        'target_shelf': 'string',
        'current_sku': 'string',
        'last_tag': 'string',
        'carrying_load': 'boolean',
        'battery_percent': 'float',
        'pose': 'geometry_msgs/Pose2D',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['geometry_msgs', 'msg'], 'Pose2D'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.state = kwargs.get('state', str())
        self.mission_id = kwargs.get('mission_id', str())
        self.target_shelf = kwargs.get('target_shelf', str())
        self.current_sku = kwargs.get('current_sku', str())
        self.last_tag = kwargs.get('last_tag', str())
        self.carrying_load = kwargs.get('carrying_load', bool())
        self.battery_percent = kwargs.get('battery_percent', float())
        from geometry_msgs.msg import Pose2D
        self.pose = kwargs.get('pose', Pose2D())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.state != other.state:
            return False
        if self.mission_id != other.mission_id:
            return False
        if self.target_shelf != other.target_shelf:
            return False
        if self.current_sku != other.current_sku:
            return False
        if self.last_tag != other.last_tag:
            return False
        if self.carrying_load != other.carrying_load:
            return False
        if self.battery_percent != other.battery_percent:
            return False
        if self.pose != other.pose:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def state(self):
        """Message field 'state'."""
        return self._state

    @state.setter
    def state(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'state' field must be of type 'str'"
        self._state = value

    @builtins.property
    def mission_id(self):
        """Message field 'mission_id'."""
        return self._mission_id

    @mission_id.setter
    def mission_id(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'mission_id' field must be of type 'str'"
        self._mission_id = value

    @builtins.property
    def target_shelf(self):
        """Message field 'target_shelf'."""
        return self._target_shelf

    @target_shelf.setter
    def target_shelf(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'target_shelf' field must be of type 'str'"
        self._target_shelf = value

    @builtins.property
    def current_sku(self):
        """Message field 'current_sku'."""
        return self._current_sku

    @current_sku.setter
    def current_sku(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'current_sku' field must be of type 'str'"
        self._current_sku = value

    @builtins.property
    def last_tag(self):
        """Message field 'last_tag'."""
        return self._last_tag

    @last_tag.setter
    def last_tag(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'last_tag' field must be of type 'str'"
        self._last_tag = value

    @builtins.property
    def carrying_load(self):
        """Message field 'carrying_load'."""
        return self._carrying_load

    @carrying_load.setter
    def carrying_load(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'carrying_load' field must be of type 'bool'"
        self._carrying_load = value

    @builtins.property
    def battery_percent(self):
        """Message field 'battery_percent'."""
        return self._battery_percent

    @battery_percent.setter
    def battery_percent(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'battery_percent' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'battery_percent' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._battery_percent = value

    @builtins.property
    def pose(self):
        """Message field 'pose'."""
        return self._pose

    @pose.setter
    def pose(self, value):
        if __debug__:
            from geometry_msgs.msg import Pose2D
            assert \
                isinstance(value, Pose2D), \
                "The 'pose' field must be a sub message of type 'Pose2D'"
        self._pose = value
