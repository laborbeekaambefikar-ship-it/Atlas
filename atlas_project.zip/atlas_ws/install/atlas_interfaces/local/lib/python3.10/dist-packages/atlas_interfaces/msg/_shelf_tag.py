# generated from rosidl_generator_py/resource/_idl.py.em
# with input from atlas_interfaces:msg/ShelfTag.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import math  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_ShelfTag(type):
    """Metaclass of message 'ShelfTag'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('atlas_interfaces')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'atlas_interfaces.msg.ShelfTag')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__msg__shelf_tag
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__msg__shelf_tag
            cls._CONVERT_TO_PY = module.convert_to_py_msg__msg__shelf_tag
            cls._TYPE_SUPPORT = module.type_support_msg__msg__shelf_tag
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__msg__shelf_tag

            from builtin_interfaces.msg import Time
            if Time.__class__._TYPE_SUPPORT is None:
                Time.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class ShelfTag(metaclass=Metaclass_ShelfTag):
    """Message class 'ShelfTag'."""

    __slots__ = [
        '_tag_id',
        '_shelf_id',
        '_distance',
        '_is_home',
        '_stamp',
    ]

    _fields_and_field_types = {
        'tag_id': 'string',
        'shelf_id': 'string',
        'distance': 'float',
        'is_home': 'boolean',
        'stamp': 'builtin_interfaces/Time',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.NamespacedType(['builtin_interfaces', 'msg'], 'Time'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.tag_id = kwargs.get('tag_id', str())
        self.shelf_id = kwargs.get('shelf_id', str())
        self.distance = kwargs.get('distance', float())
        self.is_home = kwargs.get('is_home', bool())
        from builtin_interfaces.msg import Time
        self.stamp = kwargs.get('stamp', Time())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.tag_id != other.tag_id:
            return False
        if self.shelf_id != other.shelf_id:
            return False
        if self.distance != other.distance:
            return False
        if self.is_home != other.is_home:
            return False
        if self.stamp != other.stamp:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def tag_id(self):
        """Message field 'tag_id'."""
        return self._tag_id

    @tag_id.setter
    def tag_id(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'tag_id' field must be of type 'str'"
        self._tag_id = value

    @builtins.property
    def shelf_id(self):
        """Message field 'shelf_id'."""
        return self._shelf_id

    @shelf_id.setter
    def shelf_id(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'shelf_id' field must be of type 'str'"
        self._shelf_id = value

    @builtins.property
    def distance(self):
        """Message field 'distance'."""
        return self._distance

    @distance.setter
    def distance(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'distance' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'distance' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._distance = value

    @builtins.property
    def is_home(self):
        """Message field 'is_home'."""
        return self._is_home

    @is_home.setter
    def is_home(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'is_home' field must be of type 'bool'"
        self._is_home = value

    @builtins.property
    def stamp(self):
        """Message field 'stamp'."""
        return self._stamp

    @stamp.setter
    def stamp(self, value):
        if __debug__:
            from builtin_interfaces.msg import Time
            assert \
                isinstance(value, Time), \
                "The 'stamp' field must be a sub message of type 'Time'"
        self._stamp = value
