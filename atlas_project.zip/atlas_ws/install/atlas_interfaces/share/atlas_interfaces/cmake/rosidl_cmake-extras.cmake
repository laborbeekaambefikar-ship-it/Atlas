# generated from rosidl_cmake/cmake/rosidl_cmake-extras.cmake.in

set(atlas_interfaces_IDL_FILES "msg/FleetMission.idl;msg/RobotState.idl;msg/ShelfTag.idl")
set(atlas_interfaces_INTERFACE_FILES "msg/FleetMission.msg;msg/RobotState.msg;msg/ShelfTag.msg")
