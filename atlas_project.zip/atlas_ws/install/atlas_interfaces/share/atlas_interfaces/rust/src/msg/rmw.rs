#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};


#[link(name = "atlas_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__atlas_interfaces__msg__FleetMission() -> *const std::ffi::c_void;
}

#[link(name = "atlas_interfaces__rosidl_generator_c")]
extern "C" {
    fn atlas_interfaces__msg__FleetMission__init(msg: *mut FleetMission) -> bool;
    fn atlas_interfaces__msg__FleetMission__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<FleetMission>, size: usize) -> bool;
    fn atlas_interfaces__msg__FleetMission__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<FleetMission>);
    fn atlas_interfaces__msg__FleetMission__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<FleetMission>, out_seq: *mut rosidl_runtime_rs::Sequence<FleetMission>) -> bool;
}

// Corresponds to atlas_interfaces__msg__FleetMission
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct FleetMission {

    // This member is not documented.
    #[allow(missing_docs)]
    pub mission_id: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub target_shelf: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub sku: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub priority: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub status: u8,

}



impl Default for FleetMission {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !atlas_interfaces__msg__FleetMission__init(&mut msg as *mut _) {
        panic!("Call to atlas_interfaces__msg__FleetMission__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for FleetMission {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { atlas_interfaces__msg__FleetMission__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { atlas_interfaces__msg__FleetMission__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { atlas_interfaces__msg__FleetMission__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for FleetMission {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for FleetMission where Self: Sized {
  const TYPE_NAME: &'static str = "atlas_interfaces/msg/FleetMission";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__atlas_interfaces__msg__FleetMission() }
  }
}


#[link(name = "atlas_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__atlas_interfaces__msg__RobotState() -> *const std::ffi::c_void;
}

#[link(name = "atlas_interfaces__rosidl_generator_c")]
extern "C" {
    fn atlas_interfaces__msg__RobotState__init(msg: *mut RobotState) -> bool;
    fn atlas_interfaces__msg__RobotState__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<RobotState>, size: usize) -> bool;
    fn atlas_interfaces__msg__RobotState__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<RobotState>);
    fn atlas_interfaces__msg__RobotState__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<RobotState>, out_seq: *mut rosidl_runtime_rs::Sequence<RobotState>) -> bool;
}

// Corresponds to atlas_interfaces__msg__RobotState
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct RobotState {

    // This member is not documented.
    #[allow(missing_docs)]
    pub state: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub mission_id: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub target_shelf: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub current_sku: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub last_tag: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub carrying_load: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub battery_percent: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub pose: geometry_msgs::msg::rmw::Pose2D,

}



impl Default for RobotState {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !atlas_interfaces__msg__RobotState__init(&mut msg as *mut _) {
        panic!("Call to atlas_interfaces__msg__RobotState__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for RobotState {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { atlas_interfaces__msg__RobotState__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { atlas_interfaces__msg__RobotState__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { atlas_interfaces__msg__RobotState__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for RobotState {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for RobotState where Self: Sized {
  const TYPE_NAME: &'static str = "atlas_interfaces/msg/RobotState";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__atlas_interfaces__msg__RobotState() }
  }
}


#[link(name = "atlas_interfaces__rosidl_typesupport_c")]
extern "C" {
    fn rosidl_typesupport_c__get_message_type_support_handle__atlas_interfaces__msg__ShelfTag() -> *const std::ffi::c_void;
}

#[link(name = "atlas_interfaces__rosidl_generator_c")]
extern "C" {
    fn atlas_interfaces__msg__ShelfTag__init(msg: *mut ShelfTag) -> bool;
    fn atlas_interfaces__msg__ShelfTag__Sequence__init(seq: *mut rosidl_runtime_rs::Sequence<ShelfTag>, size: usize) -> bool;
    fn atlas_interfaces__msg__ShelfTag__Sequence__fini(seq: *mut rosidl_runtime_rs::Sequence<ShelfTag>);
    fn atlas_interfaces__msg__ShelfTag__Sequence__copy(in_seq: &rosidl_runtime_rs::Sequence<ShelfTag>, out_seq: *mut rosidl_runtime_rs::Sequence<ShelfTag>) -> bool;
}

// Corresponds to atlas_interfaces__msg__ShelfTag
#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]


// This struct is not documented.
#[allow(missing_docs)]

#[repr(C)]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ShelfTag {

    // This member is not documented.
    #[allow(missing_docs)]
    pub tag_id: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub shelf_id: rosidl_runtime_rs::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub distance: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub is_home: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub stamp: builtin_interfaces::msg::rmw::Time,

}



impl Default for ShelfTag {
  fn default() -> Self {
    unsafe {
      let mut msg = std::mem::zeroed();
      if !atlas_interfaces__msg__ShelfTag__init(&mut msg as *mut _) {
        panic!("Call to atlas_interfaces__msg__ShelfTag__init() failed");
      }
      msg
    }
  }
}

impl rosidl_runtime_rs::SequenceAlloc for ShelfTag {
  fn sequence_init(seq: &mut rosidl_runtime_rs::Sequence<Self>, size: usize) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { atlas_interfaces__msg__ShelfTag__Sequence__init(seq as *mut _, size) }
  }
  fn sequence_fini(seq: &mut rosidl_runtime_rs::Sequence<Self>) {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { atlas_interfaces__msg__ShelfTag__Sequence__fini(seq as *mut _) }
  }
  fn sequence_copy(in_seq: &rosidl_runtime_rs::Sequence<Self>, out_seq: &mut rosidl_runtime_rs::Sequence<Self>) -> bool {
    // SAFETY: This is safe since the pointer is guaranteed to be valid/initialized.
    unsafe { atlas_interfaces__msg__ShelfTag__Sequence__copy(in_seq, out_seq as *mut _) }
  }
}

impl rosidl_runtime_rs::Message for ShelfTag {
  type RmwMsg = Self;
  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> { msg_cow }
  fn from_rmw_message(msg: Self::RmwMsg) -> Self { msg }
}

impl rosidl_runtime_rs::RmwMessage for ShelfTag where Self: Sized {
  const TYPE_NAME: &'static str = "atlas_interfaces/msg/ShelfTag";
  fn get_type_support() -> *const std::ffi::c_void {
    // SAFETY: No preconditions for this function.
    unsafe { rosidl_typesupport_c__get_message_type_support_handle__atlas_interfaces__msg__ShelfTag() }
  }
}


