#[cfg(feature = "serde")]
use serde::{Deserialize, Serialize};



// Corresponds to atlas_interfaces__msg__FleetMission

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct FleetMission {

    // This member is not documented.
    #[allow(missing_docs)]
    pub mission_id: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub target_shelf: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub sku: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub priority: u8,


    // This member is not documented.
    #[allow(missing_docs)]
    pub status: u8,

}



impl Default for FleetMission {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::FleetMission::default())
  }
}

impl rosidl_runtime_rs::Message for FleetMission {
  type RmwMsg = super::msg::rmw::FleetMission;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        mission_id: msg.mission_id.as_str().into(),
        target_shelf: msg.target_shelf.as_str().into(),
        sku: msg.sku.as_str().into(),
        priority: msg.priority,
        status: msg.status,
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        mission_id: msg.mission_id.as_str().into(),
        target_shelf: msg.target_shelf.as_str().into(),
        sku: msg.sku.as_str().into(),
      priority: msg.priority,
      status: msg.status,
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      mission_id: msg.mission_id.to_string(),
      target_shelf: msg.target_shelf.to_string(),
      sku: msg.sku.to_string(),
      priority: msg.priority,
      status: msg.status,
    }
  }
}


// Corresponds to atlas_interfaces__msg__RobotState

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct RobotState {

    // This member is not documented.
    #[allow(missing_docs)]
    pub state: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub mission_id: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub target_shelf: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub current_sku: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub last_tag: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub carrying_load: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub battery_percent: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub pose: geometry_msgs::msg::Pose2D,

}



impl Default for RobotState {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::RobotState::default())
  }
}

impl rosidl_runtime_rs::Message for RobotState {
  type RmwMsg = super::msg::rmw::RobotState;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        state: msg.state.as_str().into(),
        mission_id: msg.mission_id.as_str().into(),
        target_shelf: msg.target_shelf.as_str().into(),
        current_sku: msg.current_sku.as_str().into(),
        last_tag: msg.last_tag.as_str().into(),
        carrying_load: msg.carrying_load,
        battery_percent: msg.battery_percent,
        pose: geometry_msgs::msg::Pose2D::into_rmw_message(std::borrow::Cow::Owned(msg.pose)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        state: msg.state.as_str().into(),
        mission_id: msg.mission_id.as_str().into(),
        target_shelf: msg.target_shelf.as_str().into(),
        current_sku: msg.current_sku.as_str().into(),
        last_tag: msg.last_tag.as_str().into(),
      carrying_load: msg.carrying_load,
      battery_percent: msg.battery_percent,
        pose: geometry_msgs::msg::Pose2D::into_rmw_message(std::borrow::Cow::Borrowed(&msg.pose)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      state: msg.state.to_string(),
      mission_id: msg.mission_id.to_string(),
      target_shelf: msg.target_shelf.to_string(),
      current_sku: msg.current_sku.to_string(),
      last_tag: msg.last_tag.to_string(),
      carrying_load: msg.carrying_load,
      battery_percent: msg.battery_percent,
      pose: geometry_msgs::msg::Pose2D::from_rmw_message(msg.pose),
    }
  }
}


// Corresponds to atlas_interfaces__msg__ShelfTag

// This struct is not documented.
#[allow(missing_docs)]

#[cfg_attr(feature = "serde", derive(Deserialize, Serialize))]
#[derive(Clone, Debug, PartialEq, PartialOrd)]
pub struct ShelfTag {

    // This member is not documented.
    #[allow(missing_docs)]
    pub tag_id: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub shelf_id: std::string::String,


    // This member is not documented.
    #[allow(missing_docs)]
    pub distance: f32,


    // This member is not documented.
    #[allow(missing_docs)]
    pub is_home: bool,


    // This member is not documented.
    #[allow(missing_docs)]
    pub stamp: builtin_interfaces::msg::Time,

}



impl Default for ShelfTag {
  fn default() -> Self {
    <Self as rosidl_runtime_rs::Message>::from_rmw_message(super::msg::rmw::ShelfTag::default())
  }
}

impl rosidl_runtime_rs::Message for ShelfTag {
  type RmwMsg = super::msg::rmw::ShelfTag;

  fn into_rmw_message(msg_cow: std::borrow::Cow<'_, Self>) -> std::borrow::Cow<'_, Self::RmwMsg> {
    match msg_cow {
      std::borrow::Cow::Owned(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        tag_id: msg.tag_id.as_str().into(),
        shelf_id: msg.shelf_id.as_str().into(),
        distance: msg.distance,
        is_home: msg.is_home,
        stamp: builtin_interfaces::msg::Time::into_rmw_message(std::borrow::Cow::Owned(msg.stamp)).into_owned(),
      }),
      std::borrow::Cow::Borrowed(msg) => std::borrow::Cow::Owned(Self::RmwMsg {
        tag_id: msg.tag_id.as_str().into(),
        shelf_id: msg.shelf_id.as_str().into(),
      distance: msg.distance,
      is_home: msg.is_home,
        stamp: builtin_interfaces::msg::Time::into_rmw_message(std::borrow::Cow::Borrowed(&msg.stamp)).into_owned(),
      })
    }
  }

  fn from_rmw_message(msg: Self::RmwMsg) -> Self {
    Self {
      tag_id: msg.tag_id.to_string(),
      shelf_id: msg.shelf_id.to_string(),
      distance: msg.distance,
      is_home: msg.is_home,
      stamp: builtin_interfaces::msg::Time::from_rmw_message(msg.stamp),
    }
  }
}


