from setuptools import setup
setup(
    name='atlas_mission_manager',
    version='1.0.0',
    packages=['atlas_mission_manager'],
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/atlas_mission_manager']),
        ('share/atlas_mission_manager', ['package.xml']),
    ],
    install_requires=['setuptools'],
    entry_points={'console_scripts': [
        'mission_node = atlas_mission_manager.mission_node:main',
        'send_mission = atlas_mission_manager.send_mission:main',
    ]},
)
