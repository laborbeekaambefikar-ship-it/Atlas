"""CLI: ros2 run atlas_mission_manager send_mission S05"""
import sys, uuid, time
import rclpy
from atlas_interfaces.msg import FleetMission

def main():
    rclpy.init()
    node = rclpy.create_node('atlas_send_mission')
    pub = node.create_publisher(FleetMission, '/atlas/mission_cmd', 10)
    shelf = sys.argv[1] if len(sys.argv) > 1 else 'S01'
    time.sleep(0.5)
    m = FleetMission()
    m.mission_id = f'cli-{uuid.uuid4().hex[:6]}'
    m.target_shelf = shelf.upper()
    m.sku = 'SKU-001'
    m.priority = 1
    pub.publish(m)
    print(f'Sent mission {m.mission_id} -> {m.target_shelf}')
    time.sleep(0.5)
    node.destroy_node()
    rclpy.shutdown()
