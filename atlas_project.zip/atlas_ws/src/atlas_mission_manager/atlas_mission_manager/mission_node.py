"""
ATLAS Mission Manager — sole publisher on /atlas/cmd_vel.
NEVER modifies robot pose. Movement ONLY through cmd_vel.
"""
import math
import uuid
import rclpy
from rclpy.node import Node
from std_msgs.msg import Empty, Float32, String
from geometry_msgs.msg import Twist
from nav_msgs.msg import Odometry
from atlas_interfaces.msg import FleetMission, RobotState, ShelfTag

# Shelf catalog
AISLE_Y = [2, 4, 6, 8, 10]
SHELF_X = [1.0, 2.0, 3.0, 4.0]
SHELVES = {}
_i = 1
for ay in AISLE_Y:
    for sx in SHELF_X:
        SHELVES[f'S{_i:02d}'] = (sx, float(ay), (AISLE_Y.index(ay) + 1))
        _i += 1

S_IDLE = 'IDLE'
S_NAV_SPINE = 'NAV_SPINE'
S_TURNING = 'TURNING'
S_NAV_AISLE = 'NAV_AISLE'
S_AT_SHELF = 'AT_SHELF'
S_PICKUP = 'PICKUP'
S_PIVOT = 'PIVOT'
S_RET_AISLE = 'RET_AISLE'
S_RET_TURN = 'RET_TURN'
S_RET_SPINE = 'RET_SPINE'
S_DOCKED = 'DOCKED'
S_ERROR = 'ERROR'

class MissionManager(Node):
    def __init__(self):
        super().__init__('atlas_mission_manager')
        self.create_subscription(Twist, '/atlas/nav_vel', self._nav_cb, 10)
        self.create_subscription(Twist, '/atlas/turn_vel', self._turn_cb, 10)
        self.create_subscription(Empty, '/atlas/turn_done', self._turn_done, 10)
        self.create_subscription(Empty, '/atlas/junction', self._junction, 10)
        self.create_subscription(ShelfTag, '/atlas/tag_event', self._tag, 10)
        self.create_subscription(Odometry, '/atlas/odom', self._odom, 10)
        self.create_subscription(FleetMission, '/atlas/mission_cmd', self._mission_in, 10)
        self.create_subscription(Empty, '/atlas/estop', self._estop, 10)
        self.create_subscription(Empty, '/atlas/reset', self._reset_cmd, 10)
        self.pub_cmd = self.create_publisher(Twist, '/atlas/cmd_vel', 10)
        self.pub_turn = self.create_publisher(Float32, '/atlas/turn_cmd', 10)
        self.pub_state = self.create_publisher(RobotState, '/atlas/robot_state', 10)
        self.pub_log = self.create_publisher(String, '/atlas/log', 50)
        self.create_timer(1.0 / 50.0, self._tick)
        self.create_timer(1.0 / 10.0, self._pub_status)
        self.state = S_IDLE
        self.queue = []
        self.active = None
        self.nav_tw = Twist()
        self.turn_tw = Twist()
        self.junc_count = 0
        self.x = 0.0
        self.y = 0.0
        self.battery = 100.0
        self.carrying = False
        self.last_tag = ''
        self.estopped = False
        self.state_t = self._now()
        self.get_logger().info('MissionManager ready')

    def _now(self):
        return self.get_clock().now().nanoseconds * 1e-9

    def _log(self, s):
        self.get_logger().info(s)
        m = String()
        m.data = s
        self.pub_log.publish(m)

    def _go(self, ns):
        if ns != self.state:
            self._log(f'STATE {self.state} -> {ns}')
            self.state = ns
            self.state_t = self._now()

    def _nav_cb(self, msg):
        self.nav_tw = msg

    def _turn_cb(self, msg):
        self.turn_tw = msg

    def _odom(self, msg):
        self.x = msg.pose.pose.position.x
        self.y = msg.pose.pose.position.y

    def _mission_in(self, msg):
        if msg.target_shelf not in SHELVES:
            self._log(f'Rejected unknown shelf {msg.target_shelf}')
            return
        if not msg.mission_id:
            msg.mission_id = f'm-{uuid.uuid4().hex[:6]}'
        self.queue.append(msg)
        self._log(f'Queued {msg.mission_id} -> {msg.target_shelf}')

    def _estop(self, _):
        self.estopped = True
        self._go(S_ERROR)

    def _reset_cmd(self, _):
        self.estopped = False
        self.queue = []
        self.active = None
        self.carrying = False
        self._go(S_IDLE)

    def _junction(self, _):
        if self.state == S_NAV_SPINE:
            self.junc_count += 1
            target_aisle = SHELVES[self.active.target_shelf][2]
            self._log(f'Junction #{self.junc_count}/{target_aisle}')
            if self.junc_count >= target_aisle:
                m = Float32()
                m.data = -math.pi / 2.0
                self.pub_turn.publish(m)
                self._go(S_TURNING)
        elif self.state == S_RET_AISLE:
            m = Float32()
            m.data = math.pi / 2.0
            self.pub_turn.publish(m)
            self._go(S_RET_TURN)

    def _turn_done(self, _):
        if self.state == S_TURNING:
            self._go(S_NAV_AISLE)
        elif self.state == S_RET_TURN:
            self._go(S_RET_SPINE)
        elif self.state == S_PIVOT:
            self._go(S_RET_AISLE)

    def _tag(self, ev):
        self.last_tag = ev.tag_id
        if self.state == S_NAV_AISLE and not ev.is_home:
            if self.active and ev.shelf_id == self.active.target_shelf:
                self._go(S_AT_SHELF)
        elif self.state == S_RET_SPINE and ev.is_home:
            self._go(S_DOCKED)

    def _tick(self):
        now = self._now()
        dt = now - self.state_t

        if self.state == S_IDLE and self.queue and not self.estopped:
            self.active = self.queue.pop(0)
            self.junc_count = 0
            self._go(S_NAV_SPINE)
        elif self.state == S_AT_SHELF and dt > 0.5:
            self._go(S_PICKUP)
        elif self.state == S_PICKUP and dt > 2.0:
            self.carrying = True
            m = Float32()
            m.data = math.pi
            self.pub_turn.publish(m)
            self._go(S_PIVOT)
        elif self.state == S_DOCKED and dt > 1.0:
            self.carrying = False
            self.battery = 100.0
            self.active = None
            self._go(S_IDLE)
            self._log('Mission complete')

        out = Twist()
        if self.state in (S_NAV_SPINE, S_NAV_AISLE, S_RET_AISLE, S_RET_SPINE):
            out = self.nav_tw
        elif self.state in (S_TURNING, S_PIVOT, S_RET_TURN):
            out = self.turn_tw
        if self.estopped:
            out = Twist()
        self.pub_cmd.publish(out)

    def _pub_status(self):
        s = RobotState()
        s.state = self.state
        s.mission_id = self.active.mission_id if self.active else ''
        s.target_shelf = self.active.target_shelf if self.active else ''
        s.current_sku = self.active.sku if self.active else ''
        s.last_tag = self.last_tag
        s.carrying_load = self.carrying
        s.battery_percent = self.battery
        s.pose.x = self.x
        s.pose.y = self.y
        self.pub_state.publish(s)

def main(args=None):
    rclpy.init(args=args)
    node = MissionManager()
    try:
        rclpy.spin(node)
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == '__main__':
    main()
