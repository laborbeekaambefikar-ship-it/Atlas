"""
Virtual line sensor — 8 IR elements at 50Hz.
Uses odom directly as world coordinates (no transform needed).
The diff_drive plugin odom frame IS the world frame in this project because
the robot spawns at world (0,0,yaw=pi/2) and the plugin initializes odom
at the spawn pose.

KEY DESIGN: odom position IS world position. No odom_to_world conversion.
"""
import math
import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry
from std_msgs.msg import Int8MultiArray, Float32MultiArray, Empty

# World geometry — matches atlas_gazebo/worlds/warehouse.world exactly
SPINE = ((0.0, 0.0), (0.0, 12.0))  # x=0, y from 0 to 12
AISLES = [((0.0, y), (5.0, y)) for y in [2, 4, 6, 8, 10]]
ALL_LINES = [SPINE] + AISLES

# Sensor config
LINE_WIDTH = 0.08  # detection width (half=0.04m)
SENSOR_FWD = 0.10  # 10cm ahead of base_footprint
SENSOR_OFFSETS = [0.07, 0.05, 0.03, 0.01, -0.01, -0.03, -0.05, -0.07]
JUNC_THRESH = 5
JUNC_CONFIRM = 3
JUNC_COOLDOWN = 2.0


def _quat_to_yaw(q):
    return math.atan2(2*(q.w*q.z + q.x*q.y), 1 - 2*(q.y*q.y + q.z*q.z))


def _dist_to_seg(px, py, x1, y1, x2, y2):
    dx, dy = x2-x1, y2-y1
    if dx == 0 and dy == 0:
        return math.hypot(px-x1, py-y1)
    t = max(0.0, min(1.0, ((px-x1)*dx+(py-y1)*dy)/(dx*dx+dy*dy)))
    return math.hypot(px-(x1+t*dx), py-(y1+t*dy))


def _min_line_dist(px, py):
    return min(_dist_to_seg(px, py, s[0][0], s[0][1], s[1][0], s[1][1])
               for s in ALL_LINES)


class LineSensor(Node):
    def __init__(self):
        super().__init__('atlas_line_sensor')
        self.create_subscription(Odometry, '/atlas/odom', self._odom_cb, 10)
        self.pub_bin = self.create_publisher(Int8MultiArray, '/atlas/line_sensors', 10)
        self.pub_raw = self.create_publisher(Float32MultiArray, '/atlas/line_raw', 10)
        self.pub_junc = self.create_publisher(Empty, '/atlas/junction', 10)
        self.create_timer(1/50.0, self._tick)
        self._x = self._y = self._yaw = 0.0
        self._have_odom = False
        self._streak = 0
        self._last_junc = 0.0
        self.get_logger().info('LineSensor ready (8ch, 50Hz)')

    def _odom_cb(self, msg):
        # ODOM IS WORLD — no transform needed
        self._x = msg.pose.pose.position.x
        self._y = msg.pose.pose.position.y
        self._yaw = _quat_to_yaw(msg.pose.pose.orientation)
        self._have_odom = True

    def _tick(self):
        if not self._have_odom:
            return
        cs, sn = math.cos(self._yaw), math.sin(self._yaw)
        half = LINE_WIDTH / 2.0
        bits, raws = [], []
        for off in SENSOR_OFFSETS:
            sx = self._x + cs*SENSOR_FWD - sn*off
            sy = self._y + sn*SENSOR_FWD + cs*off
            d = _min_line_dist(sx, sy)
            raws.append(float(d))
            bits.append(1 if d <= half else 0)

        m = Int8MultiArray(); m.data = bits
        self.pub_bin.publish(m)
        r = Float32MultiArray(); r.data = raws
        self.pub_raw.publish(r)

        # Junction detection
        now = self.get_clock().now().nanoseconds * 1e-9
        self._streak = self._streak + 1 if sum(bits) >= JUNC_THRESH else 0
        if self._streak >= JUNC_CONFIRM and (now - self._last_junc) > JUNC_COOLDOWN:
            self._last_junc = now
            self._streak = 0
            self.pub_junc.publish(Empty())
            self.get_logger().info(f'JUNCTION at ({self._x:.2f}, {self._y:.2f})')


def main():
    rclpy.init()
    rclpy.spin(LineSensor())
    rclpy.shutdown()
