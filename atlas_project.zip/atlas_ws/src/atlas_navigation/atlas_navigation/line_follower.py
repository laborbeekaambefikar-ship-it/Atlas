"""PID line follower. Publishes to /atlas/nav_vel (not cmd_vel directly)."""
import rclpy
from rclpy.node import Node
from std_msgs.msg import Int8MultiArray
from geometry_msgs.msg import Twist

SPEED = 0.4
KP, KI, KD = 0.6, 0.0, 0.2
WEIGHTS = [1.0, 0.71, 0.43, 0.14, -0.14, -0.43, -0.71, -1.0]
GRACE = 60


class LineFollower(Node):
    def __init__(self):
        super().__init__('atlas_line_follower')
        self.create_subscription(Int8MultiArray, '/atlas/line_sensors', self._cb, 10)
        self.pub = self.create_publisher(Twist, '/atlas/nav_vel', 10)
        self.create_timer(1/50.0, self._tick)
        self._err = self._prev = self._intg = 0.0
        self._lost = GRACE + 1
        self._tw = Twist()

    def _cb(self, msg):
        bits = list(msg.data)
        total = sum(bits)
        if total == 0:
            self._lost += 1
            return
        self._err = sum(WEIGHTS[i]*bits[i] for i in range(8)) / total
        d = self._err - self._prev
        self._prev = self._err
        self._intg = max(-1, min(1, self._intg + self._err/50))
        ang = KP*self._err + KI*self._intg + KD*d
        tw = Twist()
        tw.linear.x = SPEED
        tw.angular.z = ang
        self._tw = tw
        self._lost = 0

    def _tick(self):
        if self._lost > GRACE:
            self.pub.publish(Twist())
        else:
            self.pub.publish(self._tw)


def main():
    rclpy.init()
    rclpy.spin(LineFollower())
    rclpy.shutdown()
