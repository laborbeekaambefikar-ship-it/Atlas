"""Simulated RFID tag detector."""
import math
import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry
from atlas_interfaces.msg import ShelfTag

DETECT_R = 0.5
REARM_R = 0.8
HOME = {'id': 'TAG-HOME', 'shelf': '', 'x': 0.0, 'y': 0.0, 'home': True}
AISLE_Y = [2, 4, 6, 8, 10]
SHELF_X = [1.0, 2.0, 3.0, 4.0]
TAGS = [HOME]
_i = 1
for ay in AISLE_Y:
    for sx in SHELF_X:
        TAGS.append({'id': f'TAG-S{_i:02d}', 'shelf': f'S{_i:02d}',
                     'x': sx, 'y': float(ay), 'home': False})
        _i += 1


class TagDetector(Node):
    def __init__(self):
        super().__init__('atlas_tag_detector')
        self.create_subscription(Odometry, '/atlas/odom', self._odom, 10)
        self.pub = self.create_publisher(ShelfTag, '/atlas/tag_event', 10)
        self.create_timer(1/50.0, self._tick)
        self._x = self._y = 0.0
        self._armed = {t['id']: True for t in TAGS}
        self._have = False

    def _odom(self, msg):
        self._x = msg.pose.pose.position.x
        self._y = msg.pose.pose.position.y
        self._have = True

    def _tick(self):
        if not self._have:
            return
        for t in TAGS:
            d = math.hypot(self._x - t['x'], self._y - t['y'])
            if self._armed[t['id']] and d <= DETECT_R:
                m = ShelfTag()
                m.tag_id = t['id']
                m.shelf_id = t['shelf']
                m.distance = float(d)
                m.is_home = t['home']
                m.stamp = self.get_clock().now().to_msg()
                self.pub.publish(m)
                self._armed[t['id']] = False
            elif not self._armed[t['id']] and d > REARM_R:
                self._armed[t['id']] = True


def main():
    rclpy.init()
    rclpy.spin(TagDetector())
    rclpy.shutdown()
