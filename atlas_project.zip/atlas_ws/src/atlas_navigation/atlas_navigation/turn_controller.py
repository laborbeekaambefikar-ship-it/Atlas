"""IMU-based turn controller. Publishes to /atlas/turn_vel."""
import math
import rclpy
from rclpy.node import Node
from sensor_msgs.msg import Imu
from std_msgs.msg import Float32, Empty
from geometry_msgs.msg import Twist

SPEED = 0.4
TOL = math.radians(3.0)


def _yaw(q):
    return math.atan2(2*(q.w*q.z+q.x*q.y), 1-2*(q.y*q.y+q.z*q.z))


def _wrap(a):
    return math.atan2(math.sin(a), math.cos(a))


class TurnController(Node):
    def __init__(self):
        super().__init__('atlas_turn_controller')
        self.create_subscription(Imu, '/atlas/imu', self._imu, 10)
        self.create_subscription(Float32, '/atlas/turn_cmd', self._cmd, 10)
        self.pub = self.create_publisher(Twist, '/atlas/turn_vel', 10)
        self.pub_done = self.create_publisher(Empty, '/atlas/turn_done', 10)
        self.create_timer(1/50.0, self._tick)
        self._yaw = 0.0
        self._target = 0.0
        self._dir = 0.0
        self._active = False
        self._have_imu = False

    def _imu(self, msg):
        self._yaw = _yaw(msg.orientation)
        self._have_imu = True

    def _cmd(self, msg):
        if not self._have_imu:
            return
        delta = msg.data
        self._target = _wrap(self._yaw + delta)
        self._dir = 1.0 if delta > 0 else -1.0
        self._active = True

    def _tick(self):
        tw = Twist()
        if self._active and self._have_imu:
            err = _wrap(self._target - self._yaw)
            if abs(err) < TOL:
                self._active = False
                self.pub.publish(Twist())
                self.pub_done.publish(Empty())
                return
            tw.angular.z = self._dir * SPEED
        self.pub.publish(tw)


def main():
    rclpy.init()
    rclpy.spin(TurnController())
    rclpy.shutdown()
