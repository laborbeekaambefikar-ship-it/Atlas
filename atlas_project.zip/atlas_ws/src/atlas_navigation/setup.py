from setuptools import setup
setup(
    name='atlas_navigation',
    version='1.0.0',
    packages=['atlas_navigation'],
    data_files=[
        ('share/ament_index/resource_index/packages', ['resource/atlas_navigation']),
        ('share/atlas_navigation', ['package.xml']),
    ],
    install_requires=['setuptools'],
    entry_points={'console_scripts': [
        'line_sensor    = atlas_navigation.line_sensor:main',
        'line_follower  = atlas_navigation.line_follower:main',
        'turn_controller = atlas_navigation.turn_controller:main',
        'tag_detector   = atlas_navigation.tag_detector:main',
    ]},
)
